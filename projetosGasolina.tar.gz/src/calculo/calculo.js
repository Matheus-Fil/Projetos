import React, { Component } from 'react';
import { 
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Platform
} from 'react-native';



class Calcular extends Component {
  
    calcularMelhoropcao(){
        const alcool = parseFloat(this.props.alcool.replace(',', '.'))
        const gasolina = parseFloat(this.props.gasolina.replace(',', '.'))

        if(isNaN(alcool) || isNaN(gasolina) || alcool ===0 || gasolina === 0){
            return 'Preencha os valores coretamente'
        }

        if(alcool / gasolina < 0.7){
            return 'Compensa usar Álcool'
        }else{
            return 'Compensa usar Gasolina'
        }
    }


  render() {
    return (

      <View style={styles.containerModal}>

        <Image 
        source={require('../img/gas.png')}
        style={styles.gas}
        />

        <Text style={styles.resultadoTexto}>{this.calcularMelhoropcao()}</Text>

        <Text style={styles.tituloPrecos}>Com os preços:</Text>
        <Text style={styles.precos}>
            Álcool: R$ {this.props.alcool}{'\n'}
            Gasolina: R$ {this.props.gasolina}
        </Text>

        <TouchableOpacity style={styles.botaoFechar} onPress={this.props.fechar}>
            <Text style={styles.textoBotaoFechar}>Calcular novamente</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  containerModal: {
   backgroundColor: '#191e28',
    marginTop: 10,
    alignItems:'center',
    width: 400,
    height: 790
  },
  gas:{
    marginTop: 70,
  },
  resultadoTexto:{
    marginTop: 30,
    color: '#00ff00',
    fontWeight: 'bold',
    fontSize: 30,
    textAlign: 'center',
  },
  tituloPrecos:{
    marginTop: 20,
    color: '#fff',
    fontSize: 25,
    fontWeight: 'bold',
  },
  precos:{
    marginTop: 10,
    color: '#d3d3d3'
  },
  botaoFechar:{
    marginTop: 30,
    backgroundColor: '#191e28',
    borderWidth: 1,
    borderColor: 'red',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  textoBotaoFechar:{
    color:'#fc1723',
    fontSize: 18,
    fontWeight: 'bold',

  }
 
});

export default Calcular;
