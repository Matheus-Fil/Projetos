import React, { Component } from 'react';
import { 
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  ScrollView,
  Platform
} from 'react-native';

import Calcular from './src/calculo/calculo'

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      alcool: '',
      gasolina: '',

      modalVisible: false
    };

    this.calcular = this.calcular.bind(this)
    this.calcularNovamente = this.calcularNovamente.bind(this)
  }
  calcular(){
    this.setState({modalVisible: true})
  }
  calcularNovamente(){
    this.setState({modalVisible: false})
  }

  render() {
    return (
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
          <Image 
            source={require('./src/img/logo.png')}
            style={styles.logo}
          />
          <Text style={styles.titulo}>Qual a melhor opção?</Text>

          <Text style={styles.textoAlcool}>Álcool (preço por litro):</Text>
          <TextInput 
            placeholder='Digite o valor do Álcool'
            style={styles.inputAlcool}
            onChangeText={(texto) => this.setState({alcool: texto})}
            value={this.state.alcool}
            keyboardType='numeric'
          />

          <Text style={styles.textoGasolina}>Gasolina (preço por litro):</Text>
          <TextInput 
            placeholder='Digite o valor da Gasolina'
            style={styles.inputGasolina}
            onChangeText={(texto) => this.setState({gasolina: texto})}
            value={this.state.gasolina}
            keyboardType='decimal-pad'
          />

          <TouchableOpacity style={styles.botao} onPress={this.calcular}>
            <Text style={styles.textoBotao}>Calcular</Text>
          </TouchableOpacity>
        </ScrollView>

        <Modal  transparent={true} animationType='slide' visible={this.state.modalVisible}>
          <Calcular
           fechar={this.calcularNovamente}
           alcool={this.state.alcool}
           gasolina={this.state.gasolina}
          />
        </Modal>


      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    marginTop: 24,
    alignItems:'center',
    backgroundColor: '#191e28'
  },
  logo:{
    marginTop: 24,
  },
  titulo:{
    marginTop: 28,
    fontSize: 25,
    fontWeight: 'bold',
    color: '#fff',
  },
  textoAlcool:{
    marginTop: 80,
    fontWeight: 'bold',
    color: '#fff',
    alignSelf: 'flex-start',
    marginLeft: 10
  },  
  inputAlcool:{
    marginTop: 10,
    backgroundColor: '#fff',
    marginLeft: 10,
    borderRadius: 5,
    alignSelf: 'flex-start',
    width: 360,
    height: 50,
    fontWeight: 'bold',
    fontSize: 15,
    marginBottom: 10,
  },
  textoGasolina:{
    marginTop: 15,
    fontWeight: 'bold',
    color: '#fff',
    alignSelf: 'flex-start',
    marginLeft: 10
  },
  inputGasolina:{
    marginTop: 10,
    backgroundColor: '#fff',
    marginLeft: 10,
    borderRadius: 5,
    alignSelf: 'flex-start',
    width: 360,
    height: 50,
    fontWeight: 'bold',
    fontSize: 15
  },
  botao:{
    marginTop: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fc1723',
    width: 360,
    height: 50,
    borderRadius: 5,
  },
  textoBotao:{
    color: '#fff',
    fontSize: 25,
    fontWeight: 'bold'
  },
});

export default App;
