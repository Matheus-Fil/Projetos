import { useState, useEffect } from 'react';
import { StyleSheet, Text, View, ActivityIndicator, TextInput, TouchableOpacity, Keyboard} from 'react-native';
import { PickerItem } from './src/Picker'
import { api } from './src/services/api'

export default function App() {
  const [loading, setLoading] = useState(true)
  const [moedas, setMoedas] = useState([])
  const [moedaSelecionada, setMoedaSelecionada] = useState(null)
  const [moedaBValor, setMoedaBValor] = useState("")

  const [valorMoeda, setValorMoeda] = useState(null)
  const [valorConvertido, setValorConvertido] = useState(0)

  useEffect(() => {
    async function loadMoedas() {
      const response = await api.get("all")

      let arrayMoedas = []
      Object.keys(response.data).map((key) => {
        arrayMoedas.push({
          key: key,
          label: key,
          value: key,
        })
      })

      setMoedas(arrayMoedas)
      setMoedaSelecionada(arrayMoedas[0].key)
      setLoading(false)


    }

    loadMoedas()
  }, [])

  async function converter(){
    if(moedaBValor === 0 || moedaBValor === "" || moedaSelecionada === null){
      return
    }

    const response = await api.get(`/all/${moedaSelecionada}-BRL`)

    let resultado = (response.data[moedaSelecionada].ask * parseFloat(moedaBValor) )

    setValorConvertido(`${resultado.toLocaleString("pt-BR", { style: "currency", currency: "BRL"})}`)
    setValorMoeda(moedaBValor)
    Keyboard.dismiss()
  }

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#191e29', marginTop: 30 }}>
        <ActivityIndicator color='#fff' size="large" />
      </View>
    )
  }
  return (
    <View style={styles.container}>

      <View style={styles.areaMoeda}>
        <Text style={styles.titulo}>Selecione sua moeda</Text>
        <PickerItem
          moedas={moedas}
          moedaSelecionada={moedaSelecionada}
          onChange={(moeda) => setMoedaSelecionada(moeda)}
        />
      </View>

      <View style={styles.areaValor}>
        <Text style={styles.titulo}>Digite um valor para converter em (R$)</Text>
        <TextInput
          placeholder='EX: 1.50'
          style={styles.input}
          keyboardType='numeric'
          value={moedaBValor}
          onChangeText={(valor) => setMoedaBValor(valor)}
        />
      </View>

      <TouchableOpacity style={styles.botao} onPress={converter}>
        <Text style={styles.btnTexto}>Converter</Text>
      </TouchableOpacity>

      {valorConvertido !== 0 && (
        <View style={styles.areaResultado}>
          <Text style={styles.valorConvertido}>
            {valorMoeda} {moedaSelecionada}
          </Text>

          <Text style={{ fontSize: 18, fontWeight: 500, color: '#191e29', margin: 8 }}>
            corresponde a
          </Text>

          <Text style={styles.valorConvertido}>
            {valorConvertido}
          </Text>
        </View>
      )}




    </View>
  );

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 30,
    backgroundColor: '#191e29',
    paddingTop: 60,
    alignItems: 'center'
  },
  areaMoeda: {
    backgroundColor: '#F1E3F3',
    width: '90%',
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    padding: 15,
    marginBottom: 1,
  },
  titulo: {
    fontSize: 17,
    color: '#191e29',
    fontWeight: 500,
    paddingLeft: 5,
    paddingRight: 5,
  },
  areaValor: {
    width: '90%',
    backgroundColor: '#F1E3F3',
    paddingTop: 8,
    paddingBottom: 8,
  },
  input: {
    width: '100%',
    padding: 8,
    fontSize: 16,
    color: '#191e29'
  },
  botao: {
    width: '90%',
    backgroundColor: '#84D2F6',
    height: 45,
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8
  },
  btnTexto: {
    color: '#191e29',
    fontWeight: 300,
    fontSize: 18
  },
  areaResultado: {
    width: '90%',
    backgroundColor: '#F1E3F3',
    marginTop: 34,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24
  },
  valorConvertido: {
    color: '#191e29',
    fontSize: 20,
    fontWeight: 'bold',
  }
});
